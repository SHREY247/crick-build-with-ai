"use client";

import { useRouter } from "next/navigation";

function makeRoomId() {
  return Math.random().toString(36).slice(2, 8).toUpperCase();
}

export default function HomePage() {
  const router = useRouter();
  return (
    <main className="landing">
      <div className="hero-card">
        <div className="hero-kicker">🏏 Build With AI :: Agentic Premier League</div>
        <h1>Stadium<span>Sync</span></h1>
        <p className="hero-headline">AI live commentary rooms for every cricket fan.</p>
        <p className="hero-sub">
          Point your camera at a match, choose a commentary personality, and share the live AI commentary room with friends.
        </p>
        <button className="primary-cta" onClick={() => router.push(`/room/${makeRoomId()}`)}>
          🎙️ Start Live Commentary Room
        </button>
        <div className="hero-features">
          <div className="hero-feature">
            <span>📷</span>
            <p>Point camera at match</p>
          </div>
          <div className="hero-feature">
            <span>🤖</span>
            <p>AI generates commentary</p>
          </div>
          <div className="hero-feature">
            <span>🔗</span>
            <p>Share room with friends</p>
          </div>
        </div>
        <p className="hero-pitch">
          We solve the live commentary problem by sampling frames from a live camera feed and using Gemini Vision to generate shareable, personalized cricket commentary in near real time.
        </p>
      </div>
    </main>
  );
}
